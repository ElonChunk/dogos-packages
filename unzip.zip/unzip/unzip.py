import zipfile
import os

def unzip_command(args, current_path):
    if len(args) < 2:
        print("Usage: unzip <file.zip>")
        return

    zip_path = os.path.join(current_path, args[1])

    if not os.path.isfile(zip_path):
        print(f"Zip file not found: {args[1]}")
        return

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(current_path)
    print(f"Extracted {args[1]} in {current_path}")
