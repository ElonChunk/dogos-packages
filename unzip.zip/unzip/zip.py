import zipfile
import os

def zip_command(args, current_path):
    if len(args) < 2:
        print("Usage: zip <output.zip> <file/folder> [...]")
        return

    output_zip = os.path.join(current_path, args[1])

    with zipfile.ZipFile(output_zip, 'w') as zipf:
        for item in args[2:]:
            item_path = os.path.join(current_path, item)
            if os.path.isdir(item_path):
                for root, _, files in os.walk(item_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        zipf.write(file_path, os.path.relpath(file_path, current_path))
            elif os.path.isfile(item_path):
                zipf.write(item_path, item)
            else:
                print(f"File/folder not found: {item}")
    print(f"Created zip archive: {output_zip}")
