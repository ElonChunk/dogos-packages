
import os
import zipfile

def unzip_command(command, current_path):
    parts = command.split()
    if len(parts) != 2:
        print("Usage: unzip <file.zip>")
        return

    zip_file = os.path.join(current_path, parts[1])
    if not os.path.exists(zip_file):
        print(f"File not found: {zip_file}")
        return

    extract_path = os.path.splitext(zip_file)[0]

    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
        print(f"Extracted to: {extract_path}")
    except Exception as e:
        print(f"Error unzipping file: {e}")
