
import os
import zipfile

def zip_command(command, current_path):
    parts = command.split()
    if len(parts) != 2:
        print("Usage: zip <folder>")
        return

    folder_path = os.path.join(current_path, parts[1])
    if not os.path.isdir(folder_path):
        print(f"Folder not found: {folder_path}")
        return

    zip_path = folder_path + ".zip"

    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    abs_file = os.path.join(root, file)
                    rel_path = os.path.relpath(abs_file, folder_path)
                    zipf.write(abs_file, rel_path)
        print(f"Zipped folder to: {zip_path}")
    except Exception as e:
        print(f"Error zipping folder: {e}")
