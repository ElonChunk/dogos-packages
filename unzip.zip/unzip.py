import zipfile
import os

def unzip_command(command, current_path):
    parts = command.split()
    if len(parts) != 2:
        print("Usage: unzip <file.zip>")
        return

    zip_path = os.path.join(current_path, parts[1])
    extract_path = os.path.join(current_path, parts[1].replace(".zip", ""))

    if not os.path.exists(zip_path):
        print("ZIP file not found.")
        return

    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
        print(f"Unzipped to: {extract_path}")
    except Exception as e:
        print(f"Error: {e}")
