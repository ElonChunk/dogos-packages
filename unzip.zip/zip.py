import zipfile
import os

def zip_command(command, current_path):
    parts = command.split()
    if len(parts) != 2:
        print("Usage: zip <folder>")
        return

    folder = os.path.join(current_path, parts[1])
    if not os.path.exists(folder):
        print("Folder not found.")
        return

    zip_filename = folder + ".zip"
    try:
        with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, folder)
                    zipf.write(file_path, arcname)
        print(f"Zipped to: {zip_filename}")
    except Exception as e:
        print(f"Error: {e}")
